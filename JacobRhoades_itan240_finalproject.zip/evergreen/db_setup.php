<!DOCTYPE HTML>
<html lang = "en">
<head>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class = "bg-pink-500 text-black font-mono">
<?php 
$conn = new mysqli("localhost", "root", ""); 
if ($conn->connect_error) { 
die("Connection failed: " . $conn->connect_error); 
} 
$sql = "CREATE DATABASE IF NOT EXISTS evergreen"; 
if ($conn->query($sql) === TRUE) { 
echo "<p>Database 'evergreen' created successfully.</p>"; 
} else { 
echo "<p>Error: " . $conn->error . "</p>"; 
}
  $conn->select_db("evergreen"); 
  $sql = "CREATE TABLE IF NOT EXISTS menu ( 
    id    INT AUTO_INCREMENT PRIMARY KEY, 
    item  VARCHAR(100) NOT NULL, 
    size  VARCHAR(20)  NOT NULL, 
    price FLOAT        NOT NULL 
  )"; 
  if ($conn->query($sql) === TRUE) { 
    echo "<p>Table 'menu' created successfully.</p>"; 
  } else { 
    echo "<p>Error: " . $conn->error . "</p>"; 
  } 
    $items = [ 
    ["Fresh Brewed Coffee",   "Small",  2.30], 
    ["Fresh Brewed Coffee",      "Medium", 2.75], 
    ["Fresh Brewed Coffee", "Large",  3.00], 
    ["Americano",   "Small",  2.90], 
    ["Americano",      "Medium", 3.30], 
    ["Americano", "Large",  3.50],
    ["Cappucino Latte",   "Small",  3.50],
    ["Cappucino Latte",   "Medium",  4.25],
    ["Cappucino Latte",   "Large",  4.55],
    ["Flat White",   "Small",  3.50],
    ["Flat White",   "Medium",  4.25],
    ["Flat White",   "Large",  4.55],
    ["Chai White",   "Small",  3.65],
    ["Chai White",   "Medium",  4.50],
    ["Chai White",   "Large",  4.75],
    ["Caramel Macchiato",   "Small",  4.25],
    ["Caramel Macchiato",   "Medium",  4.75],
    ["Caramel Macchiato",   "Large",  5.00],
    ["Salted Caramel Mocha Latte",   "Small",  4.25],
    ["Salted Caramel Mocha Latte",   "Medium",  4.75],
    ["Salted Caramel Mocha Latte",   "Large",  5.00],
    ["Rasberry Mocha Latte",   "Small",  4.25],
    ["Rasberry Mocha Latte",   "Medium",  4.75],
    ["Rasberry Mocha Latte",   "Large",  5.00],
    ["Herbal Tea",   "Small",  2.00],
    ["Herbal Tea",   "Medium",  2.50],
    ["Herbal Tea",   "Large",  2.75],
    ["Hot Chocolate",   "Small",  2.80],
    ["Hot Chocolate",   "Medium",  3.25],
    ["Hot Chocolate",   "Large",  3.50],
    ["Solo Espresso",   "Small",  2.00],
    ["Doppio Espresso",   "Small",  2.50],
    ["Flavored Steamer",   "Small",  2.75],
    ["Flavored Steamer",   "Medium",  3.00],
    ["Flavored Steamer",   "Large",  3.25],
    ["Flavored Latte",   "Small",  4.00],
    ["Flavored Latte",   "Medium",  4.50],
    ["Flavored Latte",   "Large",  4.75],
    ["Flavored Coffee",   "Small",  3.00],
    ["Flavored Coffee",   "Medium",  3.50],
    ["Flavored Coffee",   "Large",  3.75],
    ["Iced Coffee",   "Small",  2.35],
    ["Iced Coffee",   "Medium",  2.80],
    ["Iced Coffee",   "Large",  3.25],
    ["Iced Americano",   "Small",  3.25],
    ["Iced Americano",   "Medium",  3.50],
    ["Iced Americano",   "Large",  3.75],
    ["Iced Lattee",   "Small",  3.75],
    ["Iced Lattee",   "Medium",  4.25],
    ["Iced Lattee",   "Large",  4.75],
    ["Iced Salted Caramel Mocha",   "Small",  4.50],
    ["Iced Salted Caramel Mocha",   "Medium",  5.00],
    ["Iced Salted Caramel Mocha",   "Large",  5.25],
    ["Iced Chai Latte",   "Small",  4.25],
    ["Iced Chai Latte",   "Medium",  4.75],
    ["Iced Chai Latte",   "Large",  5.00],
    ["Iced Caramel Macchiato",   "Small",  4.50],
    ["Iced Caramel Macchiato",   "Medium",  5.00],
    ["Iced Caramel Macchiato",   "Large",  5.25],
    ["Iced Herbal Tea",   "Small",  2.25],
    ["Iced Herbal Tea",   "Medium",  2.75],
    ["Iced Herbal Tea",   "Large",  3.25],
    ["Iced Doppio",   "Small",  3.50],
    ["Iced Flavored Latte",   "Small",  4.25],
    ["Iced Flavored Latte",   "Medium",  4.75],
    ["Iced Flavored Latte",   "Large",  5.00],
    ["Iced Flavored Coffee",   "Small",  3.10],
    ["Iced Flavored Coffee",   "Medium",  3.55],
    ["Iced Flavored Coffee",   "Large",  4.00],
    ["Coffee",   "Small",  5.00],
    ["Java Chip",   "Small",  5.00],
    ["Mocha",   "Small",  5.00]
  ]; 
  foreach ($items as $row) { 
    $item  = $conn->real_escape_string($row[0]); 
    $size  = $conn->real_escape_string($row[1]); 
    $price = (float)$row[2]; 
    $conn->query( 
      //"INSERT INTO menu (item, size, price) VALUES ('$item','$size',$price)" 
    ); 
  } 
  echo "<p>Menu items imported.</p>";
$conn->close(); 
?>
<footer style="margin-top:2rem;padding:1rem;text-align:center;"> 
        <?php 
            echo "Student: Jacob Rhoades<br/>"; 
            // date() format reference: https://www.php.net/manual/en/datetime.format.php 
            echo "Rendered on " . date("Y-m-d H:i:s") . "<br/>"; 
            echo "PHP version: " . PHP_VERSION; 
        ?> 
        </footer>
</body>
</html>