<!DOCTYPE HTML>
<html lang = "en">
<head>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class = "bg-pink-500 text-black font-mono">

<?php 
  $conn = new mysqli("localhost", "root", "", "evergreen"); 
  if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error); 
  } 
  $item  = $conn->real_escape_string($_POST["item"]); 
  $size  = $conn->real_escape_string($_POST["size"]); 
  $price = (float)$_POST["price"]; 
  $sql = "INSERT INTO menu (item, size, price) 
          VALUES ('$item', '$size', $price)"; 
  if ($conn->query($sql) === TRUE) { 
    echo "<p class='bg-white text-green-800 text-center text-4xl'>Success! '$item' was added to the menu.</p>"; 
  } else { 
    echo "<p class='bg-white text-red-300 text-center text-4xl'>Error: " . $conn->error . "</p>"; 
  } 
  $conn->close(); 
  echo '<div class= "mb-4 ml-10">';
  echo '<p><a href="menu.php" class="bg-purple-500 hover:bg-green-500 text-white font-bold py-8 px-8 rounded">&larr; Back to Menu</a></p>'; 
  echo '</div>';
?>

<footer style="margin-top:2rem;padding:1rem;text-align:center;"> 
        <?php 
            echo "Student: Jacob Rhoades<br/>"; 
            // date() format reference: https://www.php.net/manual/en/datetime.format.php 
            echo "Rendered on " . date("Y-m-d H:i:s") . "<br/>"; 
            echo "PHP version: " . PHP_VERSION; 
        ?> 
        </footer>
</body>
</html>