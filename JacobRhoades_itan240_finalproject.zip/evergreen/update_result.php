<!DOCTYPE HTML>
<html lang = "en">
<head>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
<?php 
  $conn = new mysqli("localhost", "root", "", "evergreen"); 
  if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error); 
  } 
  $item  = $conn->real_escape_string($_POST["item"]); 
  $size  = $conn->real_escape_string($_POST["size"]); 
  $price = (float)$_POST["price"]; 
  $sql = "INSERT INTO menu (item, size, price) 
          VALUES ('$item', '$size', $price)"; 
  if ($conn->query($sql) === TRUE) { 
    echo "<p style='color:green;'>Success! '$item' was added to the menu.</p>"; 
  } else { 
    echo "<p style='color:red;'>Error: " . $conn->error . "</p>"; 
  } 
  $conn->close(); 
  echo '<p><a href="menu.php">&larr; Back to Menu</a></p>'; 
?>
</body>
</html>