<!DOCTYPE HTML>
<html lang = "en">
    <head>
        <title>Jacob Rhoades' Cafe Midterm Website</title>
        <link rel="stylesheet" href="styles.css">
    </head>
    <body>
        <header>
            <img src="https://www.millersville.edu/dining/img/evergreen-logo.png" alt="evergreenLogo">
            <h1>Evergreen Caf&eacute;</h1>
            <h3>A student ran and designed caf&eacute; in Millersville University!</h3>
        </header>

<hr>

        <section id="menus">
            <img src="https://s.wsj.net/public/resources/images/B3-CN962_fixbur_FR_20181204145648.jpg" alt="hotDrink" class="drinkImage">
            <table>
                <caption> Hot Drinks </caption>
                <thead>
                    <tr>
                    <th>Menu Item</th>
                    <th>Description</th>
                    <th>Small</th>
                    <th>Medium</th>
                    <th>Large</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Fresh Brewed Coffee</td>
                        <td>The classic brewed coffee!</td>
                        <td>$2.30</td>
                        <td>$2.75</td>
                        <td>$3.00</td>
                    </tr>
                    <tr>
                        <td>Americano</td>
                        <td>American classic!</td>
                        <td>$2.90</td>
                        <td>$3.30</td>
                        <td>$3.50</td>
                    </tr>
                    <tr>
                        <td>Cappucino Latte</td>
                        <td></td>
                        <td>$3.50</td>
                        <td>$4.25</td>
                        <td>$4.55</td>
                    </tr>
                    <tr>
                        <td>Flat White</td>
                        <td></td>
                        <td>$3.50</td>
                        <td>$4.25</td>
                        <td>$4.55</td>
                    </tr>
                    <tr>
                        <td>Chai White</td>
                        <td></td>
                        <td>$3.65</td>
                        <td>$4.50</td>
                        <td>$4.75</td>
                    </tr>
                    <tr>
                        <td>Caramel Macchiato</td>
                        <td></td>
                        <td>$4.25</td>
                        <td>$4.75</td>
                        <td>$5.00</td>
                    </tr>
                    <tr>
                        <td>Salted Caramel Mocha Latte</td>
                        <td></td>
                        <td>$4.25</td>
                        <td>$4.75</td>
                        <td>$5.00</td>
                    </tr>
                    <tr>
                        <td>Rasberry Mocha Latte</td>
                        <td></td>
                        <td>$4.25</td>
                        <td>$4.75</td>
                        <td>$5.00</td>
                    </tr>
                    <tr>
                        <td>Herbal Tea</td>
                        <td></td>
                        <td>$2.00</td>
                        <td>$2.50</td>
                        <td>$2.75</td>
                    </tr>
                    <tr>
                        <td>Hot Chocolate</td>
                        <td></td>
                        <td>$2.80</td>
                        <td>$3.25</td>
                        <td>$3.50</td>
                    </tr>
                    <tr>
                        <td>Solo Espresso</td>
                        <td></td>
                        <td>$2.00</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Doppio Espresso</td>
                        <td></td>
                        <td>$2.50</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Flavored Steamer</td>
                        <td></td>
                        <td>$2.75</td>
                        <td>$3.00</td>
                        <td>$3.25</td>
                    </tr>
                    <tr>
                        <td>Flavored Latte</td>
                        <td></td>
                        <td>$4.00</td>
                        <td>$4.50</td>
                        <td>$4.75</td>
                    </tr>
                    <tr>
                        <td>Flavored Coffee</td>
                        <td></td>
                        <td>$3.00</td>
                        <td>$3.50</td>
                        <td>$3.75</td>
                    </tr>
                </tbody>
            </table>

            <img src="https://www.thegunnysack.com/wp-content/uploads/2023/07/How-To-Make-Iced-Coffee-Recipe-SQ-500x500.jpg" alt="icedCoffee" class="drinkImage">

            <table>
                <caption>Iced Drinks</caption>
                <thead>
                    <tr>
                    <th>Menu Item</th>
                    <th>Description</th>
                    <th>Small</th>
                    <th>Medium</th>
                    <th>Large</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Iced Coffee</td>
                        <td>Coffee but now iced!</td>
                        <td>$2.35</td>
                        <td>$2.80</td>
                        <td>$3.25</td>
                    </tr>
                    <tr>
                        <td>Iced Americano</td>
                        <td>Americano but now iced!</td>
                        <td>$3.25</td>
                        <td>$3.50</td>
                        <td>$3.75</td>
                    </tr>
                    <tr>
                        <td>Iced Latte</td>
                        <td>Latte but now iced!</td>
                        <td>$3.75</td>
                        <td>$4.25</td>
                        <td>$4.75</td>
                    </tr>
                    <tr>
                        <td>Iced Salted Caramel Mocha</td>
                        <td>Salted Caramel but now iced!</td>
                        <td>$4.50</td>
                        <td>$5.00</td>
                        <td>$5.25</td>
                    </tr>
                    <tr>
                        <td>Iced Chai Latte</td>
                        <td>Chai Latte but now iced!</td>
                        <td>$4.25</td>
                        <td>$4.75</td>
                        <td>$5.00</td>
                    </tr>
                    <tr>
                        <td>Iced Caramel Macchiato</td>
                        <td>Caramel Macchiato but now iced!</td>
                        <td>$4.50</td>
                        <td>$5.00</td>
                        <td>$5.25</td>
                    </tr>
                    <tr>
                        <td>Iced Herbal Tea (Black, Zen, & Passion)</td>
                        <td>Herbal Tea but now iced!</td>
                        <td>$2.25</td>
                        <td>$2.75</td>
                        <td>$3.25</td>
                    </tr>
                    <tr>
                        <td>Iced Doppio</td>
                        <td>Doppio but now iced!</td>
                        <td>$3.50</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Iced Flavored Latte</td>
                        <td>Flavored Latte but now iced!</td>
                        <td>$4.25</td>
                        <td>$4.75</td>
                        <td>$5.00</td>
                    </tr>
                    <tr>
                        <td>Iced Flavored Coffee</td>
                        <td>Flavored Coffee but now iced!</td>
                        <td>$3.10</td>
                        <td>$3.55</td>
                        <td>$4.00</td>
                    </tr>
                </tbody>
            </table>

            <img src="https://tse4.mm.bing.net/th/id/OIP.CSa8zTdE5e5MXkgs1xoqHAHaHa?rs=1&pid=ImgDetMain&o=7&rm=3" alt="frapuccinoDrink" class="drinkImage">

            <table>
                <caption>Frapuccino</caption>
                <thead>
                    <th>Sold for</th>
                    <th>$5</th>
                </thead>
                <tbody>
                    <tr>
                        <td>Coffee</td>
                        <td>Caramel</td>
                    </tr>
                    <tr>
                        <td>Java Chip</td>
                        <td>Double Choclate</td>
                    </tr>
                    <tr>
                        <td>Mocha</td>
                        <td>Vanilla Bean</td>
                    </tr>
                </tbody>
            </table>

            <img src="https://images.squarespace-cdn.com/content/v1/64519a2582622c66adb5a106/0757b848-a51c-43b0-980d-62bd06fca3f0/Coffee+Flavour+wheel_Lincoln+%26+York_cropped.png" alt="flavorList" class="drinkImage">

            <table>
                <caption>Flavors</caption>
                <thead>
                    <th>For Hot Drinks</th>
                    <th>& Iced Drinks</th>
                </thead>
                <tbody>
                    <tr>
                        <td>Vanilla</td>
                        <td>Caramel</td>
                    </tr>
                    <tr>
                        <td>Toffee Nut</td>
                        <td>Hazel Nut</td>
                    </tr>
                    <tr>
                        <td>Rasberry</td>
                        <td>Mocha</td>
                    </tr>
                    <tr>
                        <td>White Chocolate</td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </section>

        <hr>

        <footer>
            <h4>Caf&eacute Hours</h4>
            <ul>
                <li>Monday - Sunday: 9am - 1pm & 6:30pm - 10:30pm</li>
                <Li>Closed 1pm - 6:30pm daily</Li>
            </ul>
            <hr>
            <p>&copy Evergreen Caf&eacute; 2026</p>
        </footer>
        <footer style="margin-top:2rem;padding:1rem;text-align:center;"> 
        <?php 
            echo "Student: Jacob Rhoades<br/>"; 
            // date() format reference: https://www.php.net/manual/en/datetime.format.php 
            echo "Rendered on " . date("Y-m-d H:i:s") . "<br/>"; 
            echo "PHP version: " . PHP_VERSION; 
        ?> 
        </footer>
    </body>
</html>