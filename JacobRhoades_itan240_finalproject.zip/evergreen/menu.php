<!DOCTYPE HTML>
<html lang = "en">
<head>
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class = "bg-pink-500 text-black font-mono">

<div class="mb-4 bg-pink-400">

    <h2 class="text-4xl font-semibold">Add a New Menu Item</h2> 

<form method="post" action="update_result.php"> 
  
  <div class="mb-4">
  <label>Item Name: 
    <input type="text" name="item" required> 
  </label><br> 
  </div>

  <div class="mb-4">
  <label>Size: 
    <input type="text" name="size" required> 
  </label><br> 
  </div>

  <div class="mb-4">
  <label>Price ($): 
    <input type="number" name="price" step="0.01" min="0" required> 
  </label><br>
  </div>

</div> 

  <div class="mb-4 ml-10">
  <button type="submit" class="bg-purple-500 hover:bg-green-500 text-white font-bold py-4 px-4 rounded">Add Item</button> 
</div>

  <h2 class="text-4xl font-semibold text-center bg-white">Current Menu</h2> 

<table border="1" cellpadding="6" cellspacing="0" class= "table-auto border border-gray-300 border-collapse bg-red-300 w-full text-center"> 
  <tr> 
 
ITAN 240 – Final Project Page 10 
    <th>ID</th><th>Item</th><th>Size</th><th>Price</th> 
  </tr> 
<?php 
  $conn = new mysqli("localhost", "root", "", "evergreen"); 
  if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); } 
  $result = $conn->query("SELECT id, item, size, price FROM menu ORDER BY id"); 
  if ($result && $result->num_rows > 0) { 
    while ($row = $result->fetch_assoc()) { 
      echo '<tr class="bg-teal-400">' 
        . '<td>' . $row["id"]    . '</td>' 
        . '<td>' . $row["item"]  . '</td>' 
        . '<td>' . $row["size"]  . '</td>' 
        . '<td>$' . number_format($row["price"], 2) . '</td>' 
        . '</tr>'; 
    } 
  } else { 
    echo '<tr><td colspan="4">No items in the menu yet.</td></tr>'; 
  } 
  $conn->close(); 
?> 
</table>
</form>
<footer style="margin-top:2rem;padding:1rem;text-align:center;"> 
        <?php 
            echo "Student: Jacob Rhoades<br/>"; 
            // date() format reference: https://www.php.net/manual/en/datetime.format.php 
            echo "Rendered on " . date("Y-m-d H:i:s") . "<br/>"; 
            echo "PHP version: " . PHP_VERSION; 
        ?> 
        </footer>
</body>
</html>