<!DOCTYPE HTML>
<html lang = "en">
<head>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <h2>Add a New Menu Item</h2> 
<form method="post" action="update_result.php"> 
  <label>Item Name: 
    <input type="text" name="item" required> 
  </label><br> 
  <label>Size: 
    <input type="text" name="size" required> 
  </label><br> 
  <label>Price ($): 
    <input type="number" name="price" step="0.01" min="0" required> 
  </label><br> 
  <button type="submit">Add Item</button> 
  <h2>Current Menu</h2> 
<table border="1" cellpadding="6" cellspacing="0"> 
  <tr> 
 
ITAN 240 – Final Project Page 10 
    <th>ID</th><th>Item</th><th>Size</th><th>Price</th> 
  </tr> 
<?php 
  $conn = new mysqli("localhost", "root", "", "evergreen"); 
  if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); } 
  $result = $conn->query("SELECT id, item, size, price FROM menu ORDER BY id"); 
  if ($result && $result->num_rows > 0) { 
    while ($row = $result->fetch_assoc()) { 
      echo '<tr>' 
        . '<td>' . $row["id"]    . '</td>' 
        . '<td>' . $row["item"]  . '</td>' 
        . '<td>' . $row["size"]  . '</td>' 
        . '<td>$' . number_format($row["price"], 2) . '</td>' 
        . '</tr>'; 
    } 
  } else { 
    echo '<tr><td colspan="4">No items in the menu yet.</td></tr>'; 
  } 
  $conn->close(); 
?> 
</table>
</form>
</body>
</html>